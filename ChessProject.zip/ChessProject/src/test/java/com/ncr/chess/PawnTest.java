package com.ncr.chess;

import org.junit.Before;
import org.junit.Test;

import com.ncr.chess.ChessBoard;
import com.ncr.chess.Pawn;

import static org.junit.Assert.*;

public class PawnTest {

    private ChessBoard chessBoard;
    private Pawn testSubject;

    @Before
    public void setUp() {
    	Board b = new Board(1,1);
        this.chessBoard = new ChessBoard();
        this.testSubject = new Pawn(b, 0 , 1, 1);
    }
    

    @Test
    public void testChessBoard_Add_Sets_XCoordinate() {
        this.chessBoard.addPiece(0, 6, 3);
        assertEquals(false, testSubject.canMoveTo(6,3));
    }

    @Test
    public void testChessBoard_Add_Sets_YCoordinate() {
        this.chessBoard.addPiece(6, 3, 0);
        assertEquals(false, testSubject.canMoveTo(6,3));
    }


    @Test
    public void testPawn_Move_IllegalCoordinates_Right_DoesNotMove() {
        chessBoard.addPiece(6, 3, 0);
        assertEquals(false, testSubject.canMoveTo(6,3));
        assertEquals(false, testSubject.canMoveTo(6,3));
    }

    @Test
    public void testPawn_Move_IllegalCoordinates_Left_DoesNotMove() {
        chessBoard.addPiece(6, 3, 0);
        testSubject.moveTo(4, 3);
        assertEquals(false, testSubject.canMoveTo(4,3));
        assertEquals(false, testSubject.canMoveTo(4,3));
    }

    @Test
    public void testPawn_Move_LegalCoordinates_Forward_UpdatesCoordinates() {
        chessBoard.addPiece(6, 3, 0);
        testSubject.moveTo(6, 2);
        assertEquals(false, testSubject.canMoveTo(6,2));
        assertEquals(false, testSubject.canMoveTo(6,2));
    }

}