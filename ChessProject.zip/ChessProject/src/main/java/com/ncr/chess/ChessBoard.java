package com.ncr.chess;

import java.util.LinkedList;
import java.util.Scanner;

public class ChessBoard {
	public static final int BLACK = 0;
	public static final int WHITE = 1;
	
	Scanner userInput = new Scanner(System.in);
	
	private int currentPlayer;
	private Board chessBoard;
	private LinkedList<Piece> blackPieces;
	private LinkedList<Piece> whitePieces;

	//Constructor
	public ChessBoard(){
		chessBoard = new Board(8,8);
		currentPlayer = WHITE;
		blackPieces = new LinkedList<Piece>();
		whitePieces = new LinkedList<Piece>();
		
	}
	
	//Add Pawn
	public Pawn addPiece(int color, int xloc, int yloc){
		Pawn pawn = new Pawn(chessBoard, color, xloc, yloc);
		pieceToColorHelper(pawn, color);
		
		return pawn;
	}	
	
	// This method only used to setup matches for testing obscure situations
	// and the overall game.
	public void testSetup() {		
		this.addPiece(BLACK, 1, 1);
		this.addPiece(BLACK, 2, 1);
		this.addPiece(BLACK, 3, 1);
		this.addPiece(BLACK, 4, 1);
		this.addPiece(BLACK, 5, 1);
		this.addPiece(BLACK, 6, 1);		
		currentPlayer = BLACK;
	}
	
	/*
	 * Continues to loop until game is over.
	 * 
	 * IS NOT COMPLETE. only to see if game is working well outside of test cases.
	 */
	public void gameLoop(){
		boolean continueGame = true;
		
		testSetup();
		
		while(continueGame){
			chessBoard.displayBoard();
						
			System.out.print("Which piece to move? X-loc: ");
			int nextX = userInput.nextInt();
			System.out.print("Y-loc: ");
			int nextY = userInput.nextInt();
			
			Piece target = chessBoard.pieceAt(nextX, nextY);
			if (target == null){
				System.out.println("That location is invalid");
				continueGame = false;
			}
			else if (target.getColor() != currentPlayer){
				System.out.println("That is not your piece");
				continueGame = false;
			}
			else {
				System.out.print("Where to move this piece? x-loc: ");
				nextX = userInput.nextInt();
				System.out.print("Y-loc: ");
				nextY = userInput.nextInt();
				
				if (target.canMoveTo(nextX, nextY)){
					target.moveTo(nextX, nextY);
				}
				else {
					System.out.println("Cannot move there");
				}
			}
		}
	}
	

	
	/**
	 * Determines whether the given player has any valid
	 * moves left to play
	 * @param player - Player who's moves are being checked
	 * @return - True if the player still has valid moves
	 */
	public boolean isLegalBoardPosition(int player){
		int oldX, oldY;
		Piece target;
		LinkedList<Piece> checkPieces;
		
		if (player == BLACK)
			checkPieces = blackPieces;
		else
			checkPieces = whitePieces;
		
		for (int x = 0; x < chessBoard.getXDimension(); x++){
			for (int y = 0; y < chessBoard.getYDimension(); y++){	
				// If any piece can move to this spot, move here
				// If king is still in check, then go to next location.
				for (Piece currentPiece : checkPieces){
					if (currentPiece.canMoveTo(x, y)){						
						target = chessBoard.pieceAt(x, y);
						oldX = currentPiece.getXLocation();
						oldY = currentPiece.getYLocation();
						
						currentPiece.moveTo(x, y);	
						
						return true;
					}
				}
			}
		}
		return false;
	}
	
	
	
	/**
	 * Removes this piece from the game
	 * 
	 * ASSERT that the removed piece is already in game.
	 * @param removeThisPiece the piece to remove.
	 */
	public void removePiece(Piece removeThisPiece){
		removeThisPiece.removePiece();
		int color = removeThisPiece.getColor();
		
		if (color == BLACK)
			blackPieces.remove(removeThisPiece);
		else
			whitePieces.remove(removeThisPiece);
	}
	
	public void switchPlayerTurn(){
		if (currentPlayer == WHITE)
			currentPlayer = BLACK;
		else currentPlayer = WHITE;
	}
		
	
	
	private void pieceToColorHelper(Piece piece, int color){
		if (color == BLACK)
			blackPieces.add(piece);
		else
			whitePieces.add(piece);
	}
	
	public int getPlayerTurn(){
		return currentPlayer;
	}
	
	public void setPlayer(int player){
		currentPlayer = player;
	}
		
}