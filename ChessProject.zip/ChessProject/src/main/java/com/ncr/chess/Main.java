package com.ncr.chess;

//main class to run the chessboard

public class Main {
	public static void main(String[] args){
		ChessBoard game = new ChessBoard();
		game.gameLoop();
	}
}